package livro.core.aplicacao;

import livro.dominio.IEntidade;

public class EntidadeAplicacao implements IEntidade{

}
