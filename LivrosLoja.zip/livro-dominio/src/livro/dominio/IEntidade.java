package livro.dominio;

public interface IEntidade {

}
