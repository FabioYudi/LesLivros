package livro.dominio;

public class Usuario extends EntidadeDominio {
	private String usuario;

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

}
