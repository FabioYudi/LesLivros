package livro.dominio;

public class Subcategoria {

}
